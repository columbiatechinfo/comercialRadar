-- ============================================================================
-- Radar Comercial — modelo de validação operacional do cruzamento
-- PostgreSQL 15+ / PostGIS 3.3+
--
-- Grão      : LIGAÇÃO (âncora = cadastro da distribuidora)
-- Observação: 1 linha por (ligação × fonte × chave na origem)
-- Decisão   : append-only; o status vigente é derivado, nunca sobrescrito
-- SRID      : armazenamento 4674 (SIRGAS 2000). Distância SEMPRE em metros,
--             pela zona UTM do município — nunca em graus, nunca constante.
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS radar;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ─────────────────────────────────────────────────── 1. catálogo (metadados)

CREATE TABLE radar.fonte (
  fonte_id      text PRIMARY KEY,
  rotulo        text     NOT NULL,
  resumo        text     NOT NULL,          -- a linha que a aba Resumo exibe
  tem_endereco  boolean  NOT NULL,
  tem_imagem    boolean  NOT NULL,
  ordem         smallint NOT NULL UNIQUE,
  contrato      text     NOT NULL DEFAULT 'FIRMADO'
                CHECK (contrato IN ('FIRMADO','PROPOSTO'))
);

-- O catálogo de campos é o que a tela usa para montar a ficha analítica.
-- Campo novo na skill de tratamento entra AQUI; a tela não muda.
CREATE TABLE radar.campo (
  fonte_id    text     NOT NULL REFERENCES radar.fonte ON DELETE CASCADE,
  col         text     NOT NULL,
  rotulo      text     NOT NULL,
  grupo       text     NOT NULL,            -- seção dentro da aba
  tipo        text     NOT NULL CHECK (tipo IN
                ('texto','int','decimal','data','bool','json','lista','imagem')),
  comparavel  boolean  NOT NULL DEFAULT false,  -- confronta com a âncora
  lgpd        boolean  NOT NULL DEFAULT false,  -- mascarar na exibição
  nota        text,
  PRIMARY KEY (fonte_id, col)
);

-- ─────────────────────────────────────────────────── 2. âncora

CREATE TABLE radar.ligacao (
  tenant             text NOT NULL,
  num_ligacao        text NOT NULL,     -- chave única da ligação; não há UC separada
  matricula          text,              -- o MESMO número, formatado para leitura humana
  situacao           text NOT NULL,
  data_ligacao       date,
  classe             text NOT NULL,
  subclasse          text,
  eco_residencial    integer NOT NULL DEFAULT 0 CHECK (eco_residencial    >= 0),
  eco_comercial      integer NOT NULL DEFAULT 0 CHECK (eco_comercial      >= 0),
  eco_industrial     integer NOT NULL DEFAULT 0 CHECK (eco_industrial     >= 0),
  eco_poder_publico  integer NOT NULL DEFAULT 0 CHECK (eco_poder_publico  >= 0),
  eco_total          integer GENERATED ALWAYS AS
                       (eco_residencial + eco_comercial + eco_industrial + eco_poder_publico) STORED,
  logradouro         text, numero text, complemento text,
  bairro             text, municipio text, uf char(2), cep text,
  cod_ibge           integer NOT NULL,
  geom               geometry(Point,4674),
  nv_geo             text CHECK (nv_geo IN
                       ('T1_DECLARADA','T2_QUADRA','T3_SETOR','T4_INTERPOLADA','SEM_POSICAO')),
  fonte_coord        text,
  hidrometro         text,
  hidrometro_situacao text CHECK (hidrometro_situacao IN
                       ('INSTALADO','RETIRADO','SEM_HIDROMETRO','NAO_LOCALIZADO')),
  hidrometro_instalacao date,
  hidrometro_capacidade text,
  imovel_id          text,                    -- resolução de entidade: 1 imóvel, N economias
  padrao_endereco    text CHECK (padrao_endereco IN
                       ('INDIVIDUAL','COLETIVO','MISTO','FRAGMENTADO')),
  consumo_medio_12m  numeric(12,2),
  ultima_leitura     date,
  ocorrencia_recorrente text,
  prioridade         integer NOT NULL DEFAULT 999,
  referencia         date NOT NULL,           -- competência da carga
  PRIMARY KEY (tenant, num_ligacao)
);

-- zona métrica por município: a distância nunca sai de constante no código
CREATE TABLE radar.srid_municipio (
  cod_ibge integer PRIMARY KEY,
  srid_metrico integer NOT NULL CHECK (srid_metrico BETWEEN 31965 AND 31985
                                    OR srid_metrico BETWEEN 31972 AND 31985)
);

-- ─────────────────────────────────────────────────── 3. observação por fonte

CREATE TABLE radar.observacao (
  observacao_id  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tenant         text NOT NULL,
  num_ligacao    text NOT NULL,
  fonte_id       text NOT NULL REFERENCES radar.fonte,
  chave_origem   text NOT NULL,               -- place_id, CNPJ, id_loja, UC, COD_UNICO…

  -- veredito do casamento: declarado, nunca implícito
  regra_match    text        NOT NULL,        -- a regra que casou, em português
  tier           text        NOT NULL CHECK (tier IN
                   ('CONCLUSIVO','FORTE','MODERADO','FRAGIL','SEM_PAR')),
  probabilidade  smallint    NOT NULL CHECK (probabilidade BETWEEN 0 AND 100),
  prob_base      text        NOT NULL DEFAULT 'DECLARADA'
                   CHECK (prob_base IN ('DECLARADA','CALIBRADA')),
  prob_n         integer,                     -- n da amostra quando CALIBRADA
  sim_logradouro numeric(4,3) CHECK (sim_logradouro BETWEEN 0 AND 1),
  num_match      boolean,
  dist_ancora_m  numeric(10,2) CHECK (dist_ancora_m >= 0),

  geom           geometry(Point,4674),
  payload        jsonb       NOT NULL,        -- campos da fonte, chaveados por radar.campo.col
  observado_em   timestamptz NOT NULL,
  run_id         text        NOT NULL,
  ingerido_em    timestamptz NOT NULL DEFAULT now(),

  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE,
  UNIQUE (tenant, num_ligacao, fonte_id, chave_origem, run_id),
  -- CALIBRADA sem n é afirmação sem lastro
  CONSTRAINT ck_calibrada_tem_n CHECK (prob_base <> 'CALIBRADA' OR prob_n IS NOT NULL)
);

-- ─────────────────────────────────────────────────── 4. veredito da IA

CREATE TABLE radar.veredito_ia (
  tenant       text NOT NULL,
  num_ligacao  text NOT NULL,
  run_id       text NOT NULL,
  veredito     text NOT NULL,
  recomendacao text NOT NULL,                 -- nomeia a CONSEQUÊNCIA cadastral
  confianca    smallint NOT NULL CHECK (confianca BETWEEN 0 AND 100),
  n_fontes_avaliadas      smallint NOT NULL,
  n_fontes_confirmadoras  smallint NOT NULL,
  familias_independentes  smallint NOT NULL,
  favoraveis   smallint NOT NULL,
  neutras      smallint NOT NULL,
  contraditorias smallint NOT NULL,
  justificativa text NOT NULL,
  contradicoes  text[] NOT NULL DEFAULT '{}',
  modelo       text NOT NULL,
  prompt_hash  text NOT NULL,
  analisado_em timestamptz NOT NULL,
  PRIMARY KEY (tenant, num_ligacao, run_id),
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE,
  CONSTRAINT ck_confirmadoras CHECK (n_fontes_confirmadoras <= n_fontes_avaliadas)
);

CREATE TABLE radar.evidencia (
  tenant      text NOT NULL,
  num_ligacao text NOT NULL,
  run_id      text NOT NULL,
  fonte_id    text NOT NULL REFERENCES radar.fonte,
  peso        text NOT NULL CHECK (peso IN ('FORTE','MEDIA','NEUTRA','CONTRARIA')),
  texto       text NOT NULL,
  PRIMARY KEY (tenant, num_ligacao, run_id, fonte_id),
  FOREIGN KEY (tenant, num_ligacao, run_id) REFERENCES radar.veredito_ia ON DELETE CASCADE
);

-- ─────────────────────────────────────────────────── 4b. leitura de imagem
-- Grão: IMAGEM. Vinculada à aba da fonte que a trouxe (fonte_id) — é o que faz a
-- mesma leitura aparecer no carrossel da aba IA das Imagens e sob o visor da fonte.

CREATE TABLE radar.imagem (
  imagem_id     bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tenant        text NOT NULL,
  num_ligacao   text NOT NULL,
  fonte_id      text NOT NULL REFERENCES radar.fonte,
  ref           text NOT NULL,               -- ponteiro da mídia; a mídia mora fora do banco
  origem        text NOT NULL CHECK (origem IN
                  ('Street View','Campo','Drone','Plataforma','Catálogo')),
  captura       date,                        -- NULL é permitido e obriga ressalva
  azimute       numeric(5,1) CHECK (azimute BETWEEN 0 AND 360),
  enquadramento text CHECK (enquadramento IN
                  ('FACHADA_FRONTAL','OBLIQUO','INTERIOR','DETALHE','INDETERMINADO')),
  qualidade     text CHECK (qualidade IN ('BOA','REGULAR','RUIM')),
  obstrucao     text,
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE,
  UNIQUE (tenant, num_ligacao, fonte_id, ref)
);

CREATE TABLE radar.imagem_leitura (
  imagem_id      bigint PRIMARY KEY REFERENCES radar.imagem ON DELETE CASCADE,
  run_id         text NOT NULL,
  -- triagem
  e_imovel       boolean,
  tipo_alvo      text CHECK (tipo_alvo IN
                   ('IMOVEL','TERRENO_VAGO','VIA','OBRA','INDETERMINADO')),
  atividade_economica text CHECK (atividade_economica IN ('SIM','NAO','INDETERMINADO')),
  nome_cliente_atividade   text CHECK (nome_cliente_atividade IN
                   ('ALVO','VIZINHO','AMBULANTE','INDETERMINADO')),
  -- leitura
  numero_ocr     text,
  ocr_confianca  numeric(4,3) CHECK (ocr_confianca BETWEEN 0 AND 1),
  letreiro       boolean,
  texto_letreiro text,
  uso_aparente   text,
  padrao_construtivo text,
  -- estrutura (unidade FÍSICA — nunca economia faturável)
  pavimentos       smallint CHECK (pavimentos       >= 0),
  unidades_visiveis smallint CHECK (unidades_visiveis >= 0),
  botoes_interfone smallint CHECK (botoes_interfone >= 0),
  caixas_correio   smallint CHECK (caixas_correio   >= 0),
  medidor_visivel  boolean,
  medidor_qtd      smallint CHECK (medidor_qtd      >= 0),
  acesso         text CHECK (acesso IN
                   ('PORTA_UNICA','PORTAO_COLETIVO','MULTIPLAS_PORTAS','GUARITA')),
  -- veredito
  veredito       text NOT NULL,
  confianca      smallint NOT NULL CHECK (confianca BETWEEN 0 AND 100),
  ressalvas      text[] NOT NULL DEFAULT '{}',
  modelo         text NOT NULL,
  analisado_em   timestamptz NOT NULL,
  -- atividade atribuída ao alvo exige que a triagem tenha decidido de quem ela é
  CONSTRAINT ck_nome_cliente_resolvido CHECK (
    atividade_economica IS DISTINCT FROM 'SIM' OR nome_cliente_atividade IS NOT NULL)
);

CREATE TABLE radar.imagem_sinal (
  imagem_id bigint NOT NULL REFERENCES radar.imagem_leitura ON DELETE CASCADE,
  ordem     smallint NOT NULL,
  peso      text NOT NULL CHECK (peso IN ('FORTE','MEDIA','NEUTRA','CONTRARIA')),
  texto     text NOT NULL,
  PRIMARY KEY (imagem_id, ordem)
);

CREATE TABLE radar.imagem_conclusao (
  tenant       text NOT NULL,
  num_ligacao  text NOT NULL,
  run_id       text NOT NULL,
  veredito     text NOT NULL,
  confianca    smallint NOT NULL CHECK (confianca BETWEEN 0 AND 100),
  n_imagens    smallint NOT NULL CHECK (n_imagens >= 0),
  n_uteis      smallint NOT NULL CHECK (n_uteis  >= 0),
  concordancia text NOT NULL CHECK (concordancia IN
                 ('CONVERGENTE','PARCIAL','DIVERGENTE','INSUFICIENTE')),
  sintese      text NOT NULL,
  contradicoes text[] NOT NULL DEFAULT '{}',
  modelo       text NOT NULL,
  analisado_em timestamptz NOT NULL,
  PRIMARY KEY (tenant, num_ligacao, run_id),
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE,
  CONSTRAINT ck_uteis CHECK (n_uteis <= n_imagens)
);

CREATE INDEX ix_img_lig ON radar.imagem (tenant, num_ligacao, fonte_id);

-- a leitura de uma imagem, do jeito que as duas telas consomem
CREATE VIEW radar.v_imagem_leitura AS
SELECT i.tenant, i.num_ligacao, i.fonte_id, i.imagem_id, i.ref, i.origem, i.captura,
       i.azimute, i.enquadramento, i.qualidade, i.obstrucao,
       l.veredito, l.confianca, l.numero_ocr, l.texto_letreiro, l.atividade_economica,
       l.nome_cliente_atividade, l.uso_aparente, l.pavimentos, l.unidades_visiveis,
       l.botoes_interfone, l.caixas_correio, l.medidor_qtd, l.acesso, l.ressalvas,
       (SELECT jsonb_agg(jsonb_build_object('peso',s.peso,'texto',s.texto) ORDER BY s.ordem)
        FROM radar.imagem_sinal s WHERE s.imagem_id = i.imagem_id) AS sinais
FROM   radar.imagem i
JOIN   radar.imagem_leitura l USING (imagem_id);

-- ─────────────────────────────────────────────────── 4c. serviço no entorno e fachada
-- O indicador do cabeçalho é DERIVADO: raio e janela são parâmetros da view, nunca
-- números redigitados na ligação.

CREATE TABLE radar.ordem_servico (
  os           text NOT NULL,
  tenant       text NOT NULL,
  tipo         text NOT NULL CHECK (tipo IN
                 ('SUBSTITUICAO_HIDROMETRO','RELIGACAO','CORTE','VAZAMENTO_RAMAL',
                  'FISCALIZACAO','REPARO_REDE','VISTORIA_CADASTRAL')),
  subtipo      text,
  data_exec    date NOT NULL,
  executante   text,
  resultado    text NOT NULL,
  observacao   text,
  geom         geometry(Point,4674) NOT NULL,
  PRIMARY KEY (tenant, os)
);
CREATE INDEX ix_os_geom ON radar.ordem_servico USING gist (geom);
CREATE INDEX ix_os_data ON radar.ordem_servico (tenant, data_exec DESC);

-- posição da OS sobre o quadro de fachada (0..1); separada da geometria real
CREATE TABLE radar.fachada (
  tenant       text NOT NULL,
  num_ligacao  text NOT NULL,
  ref          text NOT NULL,
  captura      date,
  largura_m    numeric(5,1) NOT NULL CHECK (largura_m > 0),
  coord_x      numeric(4,3) NOT NULL CHECK (coord_x BETWEEN 0 AND 1),
  coord_y      numeric(4,3) NOT NULL CHECK (coord_y BETWEEN 0 AND 1),
  coord_precisao_m numeric(6,2) NOT NULL CHECK (coord_precisao_m >= 0),
  coord_origem text NOT NULL,
  nota         text,
  PRIMARY KEY (tenant, num_ligacao),
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE
);

CREATE TABLE radar.fachada_os (
  tenant      text NOT NULL,
  num_ligacao text NOT NULL,
  os          text NOT NULL,
  x_fachada   numeric(4,3) NOT NULL CHECK (x_fachada BETWEEN 0 AND 1),
  y_fachada   numeric(4,3) NOT NULL CHECK (y_fachada BETWEEN 0 AND 1),
  PRIMARY KEY (tenant, num_ligacao, os),
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.fachada ON DELETE CASCADE,
  FOREIGN KEY (tenant, os)          REFERENCES radar.ordem_servico ON DELETE CASCADE
);

-- indicador do cabeçalho: $1 raio em metros, $2 janela em meses
CREATE FUNCTION radar.servicos_no_entorno(p_tenant text, p_raio_m numeric, p_meses int)
RETURNS TABLE (num_ligacao text, total bigint, no_ponto bigint, ultimo date)
LANGUAGE sql STABLE AS $$
  SELECT l.num_ligacao,
         count(*),
         count(*) FILTER (WHERE ST_Distance(ST_Transform(l.geom, m.srid_metrico),
                                            ST_Transform(o.geom, m.srid_metrico)) <= 5),
         max(o.data_exec)
  FROM   radar.ligacao l
  JOIN   radar.srid_municipio m ON m.cod_ibge = l.cod_ibge
  JOIN   radar.ordem_servico  o ON o.tenant = l.tenant
     AND ST_DWithin(ST_Transform(l.geom, m.srid_metrico),
                    ST_Transform(o.geom, m.srid_metrico), p_raio_m)
  WHERE  l.tenant = p_tenant
    AND  o.data_exec >= (current_date - make_interval(months => p_meses))
  GROUP  BY l.num_ligacao;
$$;

-- ─────────────────────────────────────────────────── 4d. faturas emitidas
-- Grão: LIGAÇÃO × MÊS DE REFERÊNCIA. A adimplência do cabeçalho é DERIVADA daqui,
-- por VALOR (soma paga ÷ soma emitida), nunca por contagem de faturas.

CREATE TABLE radar.fatura (
  tenant         text NOT NULL,
  num_ligacao    text NOT NULL,
  mes_referencia date NOT NULL,
  classe         text NOT NULL,                -- a classe DAQUELE mês
  consumo        numeric(10,2) NOT NULL CHECK (consumo >= 0),
  leitura_tipo   text NOT NULL CHECK (leitura_tipo IN ('REAL','ESTIMADA','NAO_REALIZADA')),
  ocorrencia_leitura text,
  valor_consumo  numeric(12,2) NOT NULL CHECK (valor_consumo >= 0),
  situacao_pagamento text NOT NULL CHECK (situacao_pagamento IN
                   ('PAGO','PARCELADO','EM_ABERTO','EM_ATRASO','CANCELADA')),
  vencimento     date NOT NULL,
  data_pagamento date,
  dias_atraso    integer NOT NULL DEFAULT 0 CHECK (dias_atraso >= 0),
  valor_comercial numeric(12,2) CHECK (valor_comercial >= 0),
  diferenca_comercial numeric(12,2) GENERATED ALWAYS AS
                   (COALESCE(valor_comercial,0) - valor_consumo) STORED,
  PRIMARY KEY (tenant, num_ligacao, mes_referencia),
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE,
  -- paga sem data de pagamento é lançamento sem lastro
  CONSTRAINT ck_pago_tem_data CHECK (situacao_pagamento NOT IN ('PAGO','PARCELADO')
                                     OR data_pagamento IS NOT NULL),
  -- leitura não real precisa dizer por quê
  CONSTRAINT ck_leitura_tem_motivo CHECK (leitura_tipo = 'REAL'
                                          OR ocorrencia_leitura IS NOT NULL)
);
CREATE INDEX ix_fat_lig ON radar.fatura (tenant, num_ligacao, mes_referencia DESC);
CREATE INDEX ix_fat_aberto ON radar.fatura (tenant, num_ligacao)
  WHERE situacao_pagamento IN ('EM_ABERTO','EM_ATRASO');

-- indicador do cabeçalho — adimplência POR VALOR na janela de p_meses
CREATE FUNCTION radar.adimplencia(p_tenant text, p_meses int DEFAULT 12)
RETURNS TABLE (num_ligacao text, adimplencia_valor_pct numeric,
               valor_emitido numeric, valor_pago numeric,
               faturas_em_aberto bigint, meses_faturados bigint,
               consumo_medio numeric, meses_leitura_nao_real bigint,
               delta_comercial numeric)
LANGUAGE sql STABLE AS $$
  SELECT f.num_ligacao,
         round(100.0 * sum(f.valor_consumo)
               FILTER (WHERE f.situacao_pagamento IN ('PAGO','PARCELADO'))
               / NULLIF(sum(f.valor_consumo),0), 1),
         sum(f.valor_consumo),
         sum(f.valor_consumo) FILTER (WHERE f.situacao_pagamento IN ('PAGO','PARCELADO')),
         count(*) FILTER (WHERE f.situacao_pagamento IN ('EM_ABERTO','EM_ATRASO')),
         count(*),
         round(avg(f.consumo), 1),
         count(*) FILTER (WHERE f.leitura_tipo <> 'REAL'),
         sum(f.diferenca_comercial)
  FROM   radar.fatura f
  WHERE  f.tenant = p_tenant
    AND  f.situacao_pagamento <> 'CANCELADA'
    AND  f.mes_referencia >= (date_trunc('month', current_date)
                              - make_interval(months => p_meses))
  GROUP  BY f.num_ligacao;
$$;

-- ─────────────────────────────────────────────────── 5. decisão (append-only)

CREATE TABLE radar.decisao (
  decisao_id   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tenant       text NOT NULL,
  num_ligacao  text NOT NULL,
  status       text NOT NULL CHECK (status IN
                 ('AGUARDANDO_ANALISE','APROVADO_IA','APROVADO_USUARIO','A_REVISAR',
                  'DIRECIONADO_CAMPO','REJEITADO')),
  decidido_por text NOT NULL,                 -- 'motor' ou login do conferente
  decidido_em  timestamptz NOT NULL DEFAULT now(),
  duracao_ms   integer CHECK (duracao_ms >= 0),
  concordou_ia boolean,                       -- mede acurácia humano × IA
  motivo       text,
  observacao   text,
  -- direcionamento a campo: a pauta viaja com a decisão, não num sistema à parte
  pauta_campo      text[],
  prioridade_campo text CHECK (prioridade_campo IN ('ALTA','NORMAL')),
  FOREIGN KEY (tenant, num_ligacao) REFERENCES radar.ligacao ON DELETE CASCADE,
  -- mandar a campo sem dizer o que verificar é mandar de novo depois
  CONSTRAINT ck_campo_tem_pauta CHECK (status <> 'DIRECIONADO_CAMPO'
    OR (pauta_campo IS NOT NULL AND cardinality(pauta_campo) > 0 AND motivo IS NOT NULL)),
  -- decisão de usuário sem motivo quando discorda da IA some da auditoria
  CONSTRAINT ck_motivo CHECK (concordou_ia IS DISTINCT FROM false OR motivo IS NOT NULL)
);
-- append-only de verdade
CREATE RULE radar_decisao_sem_update AS ON UPDATE TO radar.decisao DO INSTEAD NOTHING;
CREATE RULE radar_decisao_sem_delete AS ON DELETE TO radar.decisao DO INSTEAD NOTHING;

-- ─────────────────────────────────────────────────── 6. índices

CREATE INDEX ix_lig_geom        ON radar.ligacao   USING gist (geom);
CREATE INDEX ix_lig_prio        ON radar.ligacao   (tenant, prioridade)
                                   INCLUDE (num_ligacao, classe);
CREATE INDEX ix_lig_logr_trgm   ON radar.ligacao   USING gin (upper(logradouro) gin_trgm_ops);
CREATE INDEX ix_lig_imovel      ON radar.ligacao   (tenant, imovel_id) WHERE imovel_id IS NOT NULL;
CREATE INDEX ix_lig_hidrometro  ON radar.ligacao   (tenant, hidrometro) WHERE hidrometro IS NOT NULL;

CREATE INDEX ix_obs_lig         ON radar.observacao (tenant, num_ligacao, fonte_id);
CREATE INDEX ix_obs_geom        ON radar.observacao USING gist (geom);
CREATE INDEX ix_obs_payload     ON radar.observacao USING gin (payload jsonb_path_ops);
-- só o que a fila usa: observação forte por fonte
CREATE INDEX ix_obs_forte       ON radar.observacao (fonte_id, probabilidade DESC)
                                   WHERE tier IN ('CONCLUSIVO','FORTE');

CREATE INDEX ix_dec_ultima      ON radar.decisao   (tenant, num_ligacao, decidido_em DESC);
CREATE INDEX ix_dec_campo       ON radar.decisao   (tenant, prioridade_campo, decidido_em DESC)
  WHERE status = 'DIRECIONADO_CAMPO';

-- ─────────────────────────────────────────────────── 7. leitura (read model)

-- status vigente = última decisão; sem decisão = AGUARDANDO_ANALISE
CREATE VIEW radar.v_status_atual AS
SELECT l.tenant, l.num_ligacao, l.prioridade,
       COALESCE(d.status,'AGUARDANDO_ANALISE') AS status,
       d.decidido_por, d.decidido_em, d.concordou_ia, d.motivo
FROM   radar.ligacao l
LEFT   JOIN LATERAL (
         SELECT status, decidido_por, decidido_em, concordou_ia, motivo
         FROM   radar.decisao x
         WHERE  x.tenant = l.tenant AND x.num_ligacao = l.num_ligacao
         ORDER  BY x.decidido_em DESC, x.decisao_id DESC
         LIMIT  1) d ON true;

-- painel lateral: contagem e percentual por status, em uma passada
CREATE VIEW radar.v_status_base AS
SELECT status,
       count(*)                                                        AS ligacoes,
       round(100.0 * count(*) / NULLIF(sum(count(*)) OVER (),0), 1)    AS pct
FROM   radar.v_status_atual
GROUP  BY status;

-- ligações que dividem o mesmo imóvel — alimenta a caixa do cabeçalho
-- Derivado, nunca redigitado: a contagem sai do imovel_id da resolução de entidade.
CREATE VIEW radar.v_endereco_ligacoes AS
SELECT l.tenant, l.imovel_id,
       count(*)                                        AS ligacoes_no_endereco,
       sum(l.eco_total)                                AS economias_no_endereco,
       count(*) FILTER (WHERE l.situacao = 'ATIVA')    AS ativas,
       count(DISTINCT l.classe)                        AS classes_distintas,
       jsonb_agg(jsonb_build_object(
         'num_ligacao', l.num_ligacao, 'matricula', l.matricula, 'classe', l.classe,
         'situacao', l.situacao, 'complemento', l.complemento,
         'eco_total', l.eco_total, 'hidrometro', l.hidrometro)
         ORDER BY l.num_ligacao)                       AS ligacoes
FROM   radar.ligacao l
WHERE  l.imovel_id IS NOT NULL
GROUP  BY l.tenant, l.imovel_id;

-- lote de campo: o que foi direcionado e ainda não voltou, com a pauta consolidada
CREATE VIEW radar.v_lote_campo AS
SELECT s.tenant, s.num_ligacao, l.matricula, l.logradouro, l.numero, l.complemento, l.bairro,
       l.hidrometro, l.geom, d.motivo, d.prioridade_campo, d.pauta_campo, d.observacao,
       d.decidido_por, d.decidido_em,
       current_date - d.decidido_em::date AS dias_na_fila
FROM   radar.v_status_atual s
JOIN   radar.ligacao l USING (tenant, num_ligacao)
JOIN   LATERAL (SELECT * FROM radar.decisao x
                WHERE x.tenant = s.tenant AND x.num_ligacao = s.num_ligacao
                  AND x.status = 'DIRECIONADO_CAMPO'
                ORDER BY x.decidido_em DESC LIMIT 1) d ON true
WHERE  s.status = 'DIRECIONADO_CAMPO';

-- convergência por ligação — alimenta a régua e a ordenação da fila
CREATE MATERIALIZED VIEW radar.mv_convergencia AS
SELECT o.tenant, o.num_ligacao,
       count(*) FILTER (WHERE o.tier IN ('CONCLUSIVO','FORTE'))        AS fontes_fortes,
       count(DISTINCT o.fonte_id)                                      AS fontes_com_par,
       max(o.probabilidade)                                            AS prob_max,
       round(avg(o.probabilidade) FILTER (WHERE o.tier <> 'SEM_PAR'),1) AS prob_media,
       bool_or(o.fonte_id = 'receita'  AND o.tier IN ('CONCLUSIVO','FORTE')) AS tem_cnpj_forte,
       bool_or(o.fonte_id = 'google'   AND (o.payload->>'numero_fachada_ocr') IS NOT NULL) AS tem_ocr,
       jsonb_object_agg(o.fonte_id, jsonb_build_object(
            'p', o.probabilidade, 'tier', o.tier, 'regra', o.regra_match)) AS regua
FROM   radar.observacao o
GROUP  BY o.tenant, o.num_ligacao;

CREATE UNIQUE INDEX ux_mv_conv ON radar.mv_convergencia (tenant, num_ligacao);

-- ─────────────────────────────────────────────────── 8. consultas da tela

-- 8.1 fila: as 10 primeiras do status selecionado
--     $1 tenant · $2 status (NULL = todos)
/*
SELECT s.num_ligacao, l.matricula, l.logradouro, l.numero, l.bairro,
       s.status, c.fontes_fortes, c.prob_max
FROM   radar.v_status_atual s
JOIN   radar.ligacao        l USING (tenant, num_ligacao)
LEFT   JOIN radar.mv_convergencia c USING (tenant, num_ligacao)
WHERE  s.tenant = $1
  AND  ($2::text IS NULL OR s.status = $2)
ORDER  BY s.prioridade, c.prob_max DESC NULLS LAST
LIMIT  10;
*/

-- 8.2 dossiê completo de uma ligação, em um round-trip
/*
SELECT to_jsonb(l) - 'geom'
         || jsonb_build_object('lat', ST_Y(l.geom), 'lon', ST_X(l.geom))       AS ancora,
       (SELECT jsonb_object_agg(o.fonte_id, jsonb_build_object(
                 'probabilidade', o.probabilidade, 'tier', o.tier,
                 'prob_base', o.prob_base, 'regra_match', o.regra_match,
                 'sim_logradouro', o.sim_logradouro, 'num_match', o.num_match,
                 'campos', o.payload
                            || jsonb_build_object('dist_ancora_m', o.dist_ancora_m)))
        FROM radar.observacao o
        WHERE o.tenant = l.tenant AND o.num_ligacao = l.num_ligacao)           AS fontes,
       (SELECT to_jsonb(v) || jsonb_build_object('evidencias',
                 (SELECT jsonb_agg(jsonb_build_object('fonte', e.fonte_id,
                                                      'peso', e.peso, 'texto', e.texto)
                          ORDER BY CASE e.peso WHEN 'FORTE' THEN 1 WHEN 'MEDIA' THEN 2
                                               WHEN 'NEUTRA' THEN 3 ELSE 4 END)
                  FROM radar.evidencia e
                  WHERE (e.tenant,e.num_ligacao,e.run_id)=(v.tenant,v.num_ligacao,v.run_id)))
        FROM radar.veredito_ia v
        WHERE v.tenant = l.tenant AND v.num_ligacao = l.num_ligacao
        ORDER BY v.analisado_em DESC LIMIT 1)                                  AS ia
FROM   radar.ligacao l
WHERE  l.tenant = $1 AND l.num_ligacao = $2;
*/

-- 8.3 distância em METROS pela zona do município (jamais em graus)
--     use no ETL para gravar observacao.dist_ancora_m
/*
UPDATE radar.observacao o
SET    dist_ancora_m = ST_Distance(
         ST_Transform(l.geom, m.srid_metrico),
         ST_Transform(o.geom, m.srid_metrico))
FROM   radar.ligacao l
JOIN   radar.srid_municipio m ON m.cod_ibge = l.cod_ibge
WHERE  o.tenant = l.tenant AND o.num_ligacao = l.num_ligacao
  AND  o.geom IS NOT NULL AND l.geom IS NOT NULL
  AND  o.run_id = $1;
*/

-- 8.4 produtividade e acurácia humano × IA (a métrica que justifica a tela)
/*
SELECT date_trunc('day', d.decidido_em)                        AS dia,
       d.decidido_por,
       count(*)                                                AS decisoes,
       round(avg(d.duracao_ms)/1000.0, 1)                      AS seg_por_ligacao,
       round(100.0 * count(*) FILTER (WHERE d.concordou_ia)
                    / NULLIF(count(*) FILTER (WHERE d.concordou_ia IS NOT NULL),0), 1)
                                                               AS pct_concordancia_ia
FROM   radar.decisao d
WHERE  d.decidido_por <> 'motor' AND d.tenant = $1
GROUP  BY 1,2
ORDER  BY 1 DESC, 2;
*/

-- ─────────────────────────────────────────────────── 9. gates de carga
-- Rodar depois de cada run. Qualquer linha devolvida reprova a carga.
/*
SELECT 'observacao sem regra declarada' AS gate, count(*) AS n
FROM   radar.observacao WHERE coalesce(regra_match,'') = '' HAVING count(*) > 0
UNION ALL
SELECT 'tier forte sem número conferido em fonte com endereço', count(*)
FROM   radar.observacao o JOIN radar.fonte f USING (fonte_id)
WHERE  f.tem_endereco AND o.tier IN ('CONCLUSIVO','FORTE')
  AND  o.num_match IS DISTINCT FROM true HAVING count(*) > 0
UNION ALL
SELECT 'delivery acima de MODERADO sem endereço exato', count(*)
FROM   radar.observacao
WHERE  fonte_id = 'delivery' AND tier IN ('CONCLUSIVO','FORTE')
  AND  payload->>'endereco_precisao' IS DISTINCT FROM 'EXATO'
  AND  payload->>'cnpj_declarado' IS NULL HAVING count(*) > 0
UNION ALL
SELECT 'economias negativas ou total divergente', count(*)
FROM   radar.ligacao WHERE eco_total = 0 AND situacao = 'ATIVA' HAVING count(*) > 0
UNION ALL
SELECT 'matricula que nao e o mesmo numero da ligacao', count(*)
FROM   radar.ligacao
WHERE  matricula IS NOT NULL
  AND  regexp_replace(matricula, '\\D', '', 'g') <> regexp_replace(num_ligacao, '\\D', '', 'g')
HAVING count(*) > 0
UNION ALL
SELECT 'ligação sem coordenada e sem nv_geo declarado', count(*)
FROM   radar.ligacao WHERE geom IS NULL AND nv_geo IS DISTINCT FROM 'SEM_POSICAO'
HAVING count(*) > 0
UNION ALL
SELECT 'direcionado a campo sem pauta ou sem motivo', count(*)
FROM   radar.decisao WHERE status = 'DIRECIONADO_CAMPO'
  AND  (pauta_campo IS NULL OR cardinality(pauta_campo) = 0 OR motivo IS NULL)
HAVING count(*) > 0
UNION ALL
SELECT 'fatura paga sem data de pagamento', count(*)
FROM   radar.fatura WHERE situacao_pagamento IN ('PAGO','PARCELADO')
  AND  data_pagamento IS NULL HAVING count(*) > 0
UNION ALL
SELECT 'leitura nao real sem ocorrencia declarada', count(*)
FROM   radar.fatura WHERE leitura_tipo <> 'REAL'
  AND  coalesce(ocorrencia_leitura,'') = '' HAVING count(*) > 0
UNION ALL
SELECT 'valor comercial menor que o valor faturado', count(*)
FROM   radar.fatura WHERE valor_comercial IS NOT NULL
  AND  valor_comercial < valor_consumo HAVING count(*) > 0
UNION ALL
SELECT 'OS marcada na fachada sem posicao no quadro', count(*)
FROM   radar.ordem_servico o
WHERE  NOT EXISTS (SELECT 1 FROM radar.fachada_os f WHERE f.tenant=o.tenant AND f.os=o.os)
  AND  EXISTS (SELECT 1 FROM radar.fachada f WHERE f.tenant=o.tenant) HAVING count(*) > 0
UNION ALL
SELECT 'fachada com incerteza maior que a testada enquadrada', count(*)
FROM   radar.fachada WHERE coord_precisao_m * 2 > largura_m HAVING count(*) > 0
UNION ALL
SELECT 'hidrometro repetido em imoveis diferentes', count(*)
FROM  (SELECT hidrometro FROM radar.ligacao
       WHERE hidrometro IS NOT NULL AND hidrometro_situacao = 'INSTALADO'
       GROUP BY tenant, hidrometro HAVING count(DISTINCT imovel_id) > 1) x
HAVING count(*) > 0
UNION ALL
SELECT 'ligacao ativa sem hidrometro e sem motivo declarado', count(*)
FROM   radar.ligacao
WHERE  situacao = 'ATIVA' AND hidrometro IS NULL AND hidrometro_situacao IS NULL
HAVING count(*) > 0
UNION ALL
SELECT 'imagem sem data e sem ressalva declarada', count(*)
FROM   radar.imagem i JOIN radar.imagem_leitura l USING (imagem_id)
WHERE  i.captura IS NULL AND cardinality(l.ressalvas) = 0 HAVING count(*) > 0
UNION ALL
SELECT 'atividade atribuida ao alvo sem nome_cliente resolvido', count(*)
FROM   radar.imagem_leitura
WHERE  atividade_economica = 'SIM' AND nome_cliente_atividade = 'INDETERMINADO' HAVING count(*) > 0
UNION ALL
SELECT 'conclusao de imagem contando mais imagens do que existem', count(*)
FROM   radar.imagem_conclusao c
WHERE  c.n_imagens <> (SELECT count(*) FROM radar.imagem i
                       WHERE i.tenant = c.tenant AND i.num_ligacao = c.num_ligacao)
HAVING count(*) > 0;
*/
