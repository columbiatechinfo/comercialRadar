# Radar Comercial — modelo de dados da tela de validação

Grão: **ligação**. Âncora: **cadastro da distribuidora**. Toda fonte externa é uma *observação* com endereço, imagem opcional, regra de casamento declarada, tier e probabilidade.

DDL em `radar_comercial_schema.sql`. Payload de exemplo em `radar_comercial_dataset.json`. Painel em `Radar_Comercial.html`. Este documento é **gerado do próprio dataset**: campo que não está no catálogo não aparece aqui nem na tela.

## Procedência deste modelo

Busquei no histórico o `.md` da conversa em que a tela de aprovação foi definida e o material da skill de delivery. **Nenhum dos dois apareceu** — a busca de conversas fica restrita a chats fora de projeto, e não há skill `delivery` instalada em `/mnt/skills/user`. O modelo abaixo foi montado do que está registrado e é verificável:

| Esfera | De onde vieram os campos | Situação |
|---|---|---|
| Cadastro / âncora | catálogo de fontes canônicas do painel de conferência + `tratamento-cadastro-comercial` | firmado |
| POI | `tratamento-poi-google` (ghost, vitalidade V1–V5, prova de vida, formalidade em 5 tiers, reputação) | firmado |
| Comentários da internet | derivados de reputação do mesmo pipeline (`dias_atras`, `menciona_encerramento`) | firmado |
| Informações Google | painel do Google + Street View + `leitura-fachada-cadastral` | firmado |
| Receita Federal | `tratamento-cnpj` v2.5.x — eixos `XFERA_*`, classe física F1–F12 | firmado |
| Energia | cadastro da distribuidora e BDGD/ANEEL | firmado |
| Outras Fontes | `tratamento-imoveis-ibge` (CNEFE/RCC), OSM, Overture, IPTU | firmado |
| Imagem | `leitura-fachada-cadastral` (triagem, titular da atividade, estrutura de unidades) | firmado |
| Serviço no entorno | ordens de serviço da concessionária | firmado |
| **Delivery** | **contrato proposto por mim** — não há fonte anterior registrada | **a confirmar** |
| **Redes Sociais** | **contrato proposto por mim** | **a confirmar** |

> Se o `.md` da tela de aprovação e o material de delivery existirem, cole-os ou abra a conversa dentro do projeto onde eles estão: eu reconcilio campo a campo e marco o que diverge.

## Vocabulários fechados

**Status da base** (a lateral conta e percentualiza estes cinco, e só estes):

- `AGUARDANDO_ANALISE` — Aguardando análise
- `APROVADO_IA` — Aprovado por IA
- `APROVADO_USUARIO` — Aprovado por usuário
- `A_REVISAR` — A revisar
- `DIRECIONADO_CAMPO` — Direcionado a campo
- `REJEITADO` — Rejeitado

**Tier do casamento**: `CONCLUSIVO` · `FORTE` · `MODERADO` · `FRAGIL` · `SEM_PAR`

**Peso da evidência**: `FORTE` · `MEDIA` · `NEUTRA` · `CONTRARIA`

**Concordância entre imagens**: `CONVERGENTE` · `PARCIAL` · `DIVERGENTE` · `INSUFICIENTE`

**Titular da atividade na imagem**: `ALVO` · `VIZINHO` · `AMBULANTE` · `INDETERMINADO`

**Situação do pagamento**: `PAGO` · `PARCELADO` · `EM_ABERTO` · `EM_ATRASO` · `CANCELADA`

**Tipo de leitura**: `REAL` · `ESTIMADA` · `NAO_REALIZADA`

**Motivo do direcionamento a campo**: `HIDROMETRO_NAO_LOCALIZADO` · `CONTAGEM_DE_ECONOMIAS` · `ATIVIDADE_A_CONFIRMAR` · `EVIDENCIA_DESATUALIZADA` · `ENDERECO_A_CONFIRMAR` · `COORDENADA_IMPRECISA`

**Pauta da visita**: `LOCALIZAR_HIDROMETRO` · `CONTAR_ECONOMIAS` · `CONFIRMAR_ATIVIDADE` · `CONFIRMAR_NUMERO` · `AMARRAR_HIDROMETROS` · `REGISTRAR_COORDENADA` · `FOTOGRAFAR_FACHADA`

**Base da probabilidade**: `DECLARADA` (padrão) · `CALIBRADA` (exige `prob_n`)

> A probabilidade **ordena e explica; não é probabilidade calibrada.** Só vira `CALIBRADA` com amostra rotulada de campo e `n` declarado. O DDL tem `CHECK` que impede `CALIBRADA` sem `n`.

## Âncora — cadastro da distribuidora

**Tudo da âncora vive no cabeçalho** — não há cartão de âncora dentro das abas. O cabeçalho tem duas faixas:

- **Faixa 1 — quem é:** número da ligação, **nome do cliente** e endereço completo **em uma única linha**; à direita o status e o `imovel_id`. Não há UC na âncora: o número da ligação é único, e a matrícula é esse mesmo número formatado — um gate do banco reprova matrícula cujos dígitos não batam com `num_ligacao`.
- **Faixa 2 — como está:** classe·subclasse, situação, economias por tipo, hidrômetro e coordenadas.

**O que saiu da tela e continua no modelo.** O cabeçalho foi enxugado: `ocorrencia_recorrente`, `padrao_endereco`, `nv_geo`, `hidrometro_situacao` e `hidrometro_capacidade` deixaram de ser impressos, e com eles saíram o nome do lote e a âncora no rodapé da lateral e a legenda da linha de probabilidade. Os campos **não foram removidos do modelo**, porque continuam decidindo coisa:

| Campo | Sumiu de | Ainda decide |
|---|---|---|
| `ocorrencia_recorrente` | cabeçalho | marca *localizar o hidrômetro* na pauta de campo |
| `hidrometro_situacao` | cabeçalho | marca a pauta e **pinta o número em vermelho** quando não é INSTALADO; o estado fica no `title` |
| `hidrometro_capacidade` | cabeçalho | `title` do hidrômetro |
| `nv_geo` | cabeçalho | marca *registrar coordenada* na pauta; fica no `title` |
| `padrao_endereco` | cabeçalho | nota da caixa de mesmo endereço |
| `imovel_id` | cabeçalho | `title` do status e a caixa de mesmo endereço |
| `meta.base` · `meta.fonte_ancora` | rodapé da lateral | confirmação ao carregar outro dataset |
| legenda da linha de probabilidade | cabeçalho | os mesmos números seguem no Resumo e na aba da IA |

Se algum deles precisar sair do modelo também, o que quebra junto é a linha correspondente da pauta de campo — ela é derivada desses fatos, não digitada.

Acima das duas, como primeira linha do painel, a **linha de probabilidade**: uma marca por fonte posicionada pela probabilidade, mais a marca `Fotos` com a confiança da leitura de imagem.

`●` marca o campo confrontado com as fontes.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `num_ligacao` | Nº da ligação | identificação | texto | ● | chave única da ligação; matrícula é o mesmo número formatado |
| `matricula` | Matrícula | identificação | texto |  |  |
| `situacao` | Situação | identificação | texto |  | Cortada conta como Ativa no cruzamento |
| `data_ligacao` | Data da ligação | identificação | data |  |  |
| `classe` | Classe | classificação | texto | ● |  |
| `subclasse` | Subclasse | classificação | texto | ● |  |
| `eco_residencial` | Economias residenciais | economias | int | ● |  |
| `eco_comercial` | Economias comerciais | economias | int | ● |  |
| `eco_industrial` | Economias industriais | economias | int | ● |  |
| `eco_poder_publico` | Economias poder público | economias | int | ● |  |
| `eco_total` | Total de economias | economias | int | ● |  |
| `logradouro` | Logradouro | endereço | texto | ● |  |
| `numero` | Número | endereço | texto | ● |  |
| `complemento` | Complemento | endereço | texto | ● |  |
| `bairro` | Bairro | endereço | texto | ● |  |
| `municipio` | Município | endereço | texto | ● |  |
| `uf` | UF | endereço | texto | ● |  |
| `cep` | CEP | endereço | texto | ● |  |
| `lat` | Latitude | geo | decimal | ● |  |
| `lon` | Longitude | geo | decimal | ● |  |
| `nv_geo` | Nível da coordenada | geo | texto |  | T1 declarada · T2 quadra · T3 setor · T4 interpolada |
| `fonte_coord` | Origem da coordenada | geo | texto |  |  |
| `imovel_id` | ID do imóvel físico | geo | texto |  | resolução de entidade; 1 imóvel, N economias |
| `padrao_endereco` | Padrão do endereço | geo | texto |  | INDIVIDUAL · COLETIVO · MISTO · FRAGMENTADO |
| `hidrometro` | Nº do hidrômetro | medição | texto | ● | chave de campo: é o que o leiturista encontra na caixa |
| `hidrometro_situacao` | Situação do hidrômetro | medição | texto | ● | INSTALADO · RETIRADO · SEM_HIDROMETRO · NAO_LOCALIZADO |
| `hidrometro_instalacao` | Instalação do hidrômetro | medição | data |  |  |
| `hidrometro_capacidade` | Capacidade | medição | texto |  |  |
| `ligacoes_no_endereco` | Ligações no mesmo endereço | coletivo | int | ● | conta a própria; acima de 1 exige conferir individualização antes de decidir |
| `economias_no_endereco` | Economias somadas no endereço | coletivo | int | ● | soma das economias de todas as ligações do mesmo imovel_id |
| `nome_cliente` | Nome do cliente | cliente | texto |  | exibido no cabeçalho; mascarado em qualquer exportação |
| `documento` | CPF/CNPJ do cliente | cliente | texto |  |  |
| `servicos_proximos_total` | Serviços executados no entorno | serviço | int | ● | conta OS concluídas dentro do raio e da janela declarados |
| `servicos_proximos_raio_m` | Raio considerado (m) | serviço | int |  |  |
| `servicos_proximos_janela_meses` | Janela considerada (meses) | serviço | int |  |  |
| `servicos_no_ponto` | Serviços no próprio ponto | serviço | int | ● | distância ≤ 5 m — encostou na ligação, não na vizinhança |
| `ultimo_servico` | Último serviço no entorno | serviço | data | ● |  |
| `adimplencia_valor_pct` | Adimplência do cliente (valor) | faturamento | decimal | ● | valor pago ÷ valor emitido na janela; por VALOR, não por número de faturas |
| `valor_emitido_12m` | Valor emitido na janela | faturamento | decimal |  |  |
| `valor_pago_12m` | Valor pago na janela | faturamento | decimal |  |  |
| `faturas_em_aberto` | Faturas em aberto | faturamento | int | ● |  |
| `meses_faturados` | Meses faturados na janela | faturamento | int |  |  |
| `consumo_medio_12m` | Consumo médio 12m | consumo | decimal |  |  |
| `ultima_leitura` | Última leitura | consumo | data |  |  |
| `ocorrencia_recorrente` | Ocorrência recorrente | consumo | texto |  |  |

### Lista do endereço — `endereco_ligacoes[]`

| Campo | Tipo | Para quê |
|---|---|---|
| `num_ligacao` | texto | abre a ligação vizinha na própria tela |
| `matricula` | texto | o que o operador reconhece |
| `classe` · `situacao` | texto | comercial cortada ao lado de residencial ativa é o padrão que interessa |
| `complemento` | texto | LOJA 01, AP 401, FUNDOS — separa quem é quem no mesmo número |
| `eco_total` | int | a soma tem de bater com `economias_no_endereco` |
| `hidrometro` | texto | resolve “qual hidrômetro é de qual ligação” antes do campo |

## Aba POI

*Estabelecimento georreferenciado no endereço da ligação*  
Endereço: sim · Imagem: sim · 34 campos catalogados.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `fonte_poi` | Fonte do POI | identificação | texto |  | Places · Overture · OSM · Foursquare |
| `place_id` | place_id | identificação | texto |  |  |
| `cid_hex` | CID (hex da maps_url) | identificação | texto |  |  |
| `nome` | Nome | identificação | texto | ● |  |
| `nome_normalizado` | Nome normalizado | identificação | texto |  |  |
| `categoria_xfera` | Categoria (12 setores) | identificação | texto | ● |  |
| `segmento` | Segmento | identificação | texto |  |  |
| `logradouro` | Logradouro | endereço | texto | ● |  |
| `numero` | Número | endereço | texto | ● |  |
| `complemento` | Complemento | endereço | texto | ● |  |
| `bairro` | Bairro | endereço | texto | ● |  |
| `cep` | CEP | endereço | texto | ● |  |
| `endereco_bruto` | Endereço como veio | endereço | texto |  |  |
| `lat` | Latitude | geo | decimal | ● |  |
| `lon` | Longitude | geo | decimal | ● |  |
| `dist_ancora_m` | Distância à âncora (m) | geo | decimal | ● |  |
| `business_status` | business_status | operação | texto | ● |  |
| `ghost_flag` | Ghost listing | operação | bool |  |  |
| `vitalidade` | Vitalidade | operação | texto |  | V1 a V5 |
| `prova_vida` | Prova de vida | operação | texto |  | ALTA · MEDIA · BAIXA · SEM_SINAL |
| `padrao_operacao` | Padrão de operação | operação | texto |  |  |
| `horario_semana` | Horário da semana | operação | json |  |  |
| `nota_media` | Nota média | reputação | decimal |  |  |
| `qtd_avaliacoes` | Qtd. de avaliações | reputação | int |  |  |
| `distribuicao_notas` | Distribuição das notas | reputação | json |  |  |
| `ultima_avaliacao` | Última avaliação | reputação | data |  |  |
| `telefone_e164` | Telefone (E.164) | contato | texto |  |  |
| `site` | Site | contato | texto |  |  |
| `tier_formalidade` | Formalidade cadastral | formalidade | texto |  | 5 tiers |
| `conf_nome` | Confiabilidade do nome | confiabilidade | texto |  |  |
| `conf_endereco` | Confiabilidade do endereço | confiabilidade | texto |  |  |
| `conf_geo` | Confiabilidade da geo | confiabilidade | texto |  |  |
| `url_foto` | Imagem | imagem | imagem |  |  |
| `data_foto` | Data da imagem | imagem | data |  |  |

## Aba Comentários da internet

*Avaliações públicas que datam a operação no ponto*  
Endereço: sim · Imagem: sim · 12 campos catalogados.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `fonte` | Fonte | identificação | texto |  | Google · TripAdvisor · Reclame Aqui · Facebook |
| `n_comentarios` | Comentários coletados | volume | int |  |  |
| `n_comentarios_12m` | Comentários nos últimos 12m | volume | int |  |  |
| `nota_media` | Nota média | volume | decimal |  |  |
| `ultima_avaliacao` | Comentário mais recente | volume | data | ● |  |
| `prova_vida` | Prova de vida | volume | texto | ● |  |
| `menciona_encerramento` | Menciona encerramento | sinais | bool | ● |  |
| `menciona_endereco` | Menciona o endereço | sinais | bool | ● |  |
| `menciona_atendimento_local` | Menciona atendimento no local | sinais | bool | ● |  |
| `menciona_entrega` | Menciona entrega | sinais | bool |  |  |
| `comentarios` | Comentários | comentários | lista |  | autor mascarado · estrelas · data · texto · url |
| `url_foto` | Imagem publicada | imagem | imagem |  |  |

## Aba Redes Sociais

*Perfil ativo que declara endereço, telefone ou CNPJ*  
Endereço: não · Imagem: sim · 14 campos catalogados.

**Trava dura desta fonte:** rede social não tem endereço auditável — vale o que o próprio perfil declara. Sem CNPJ, endereço ou geotag no perfil, corrobora e nunca decide sozinha.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `plataforma` | Plataforma | identificação | texto |  | Instagram · Facebook · LinkedIn · WhatsApp Business |
| `handle` | Perfil | identificação | texto | ● |  |
| `url` | URL | identificação | texto |  |  |
| `nome_exibicao` | Nome exibido | identificação | texto | ● |  |
| `bio` | Descrição do perfil | identificação | texto |  |  |
| `seguidores` | Seguidores | atividade | int |  |  |
| `n_publicacoes` | Publicações | atividade | int |  |  |
| `ultima_publicacao` | Última publicação | atividade | data | ● |  |
| `publica_endereco` | Publica endereço | declarado | bool | ● |  |
| `endereco_declarado` | Endereço declarado no perfil | declarado | texto | ● |  |
| `telefone_declarado` | Telefone declarado | declarado | texto |  |  |
| `cnpj_declarado` | CNPJ declarado | declarado | texto | ● |  |
| `geotag_local` | Geotag usada nas publicações | declarado | texto | ● |  |
| `coerencia_nome` | Coerência com o nome do POI | match | texto |  |  |

## Aba Informações Google

*Painel do Google e leitura da fachada em Street View*  
Endereço: sim · Imagem: sim · 19 campos catalogados.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `titulo_knowledge` | Título no painel do Google | identificação | texto | ● |  |
| `categoria_google` | Categoria declarada | identificação | texto | ● |  |
| `url_maps` | Link do Maps | identificação | texto |  |  |
| `endereco_formatado` | Endereço formatado | endereço | texto | ● |  |
| `plus_code` | Plus Code | endereço | texto |  |  |
| `lat` | Latitude | geo | decimal | ● |  |
| `lon` | Longitude | geo | decimal | ● |  |
| `dist_ancora_m` | Distância à âncora (m) | geo | decimal | ● |  |
| `url_streetview` | Street View | imagem | imagem |  |  |
| `heading` | Azimute da câmera | imagem | decimal |  |  |
| `data_captura` | Data da captura | imagem | data | ● |  |
| `numero_fachada_ocr` | Número lido na fachada | leitura de imagem | texto | ● | OCR × número do cadastro é o teste independente |
| `ocr_confianca` | Confiança do OCR | leitura de imagem | decimal |  |  |
| `letreiro_detectado` | Letreiro detectado | leitura de imagem | bool | ● |  |
| `texto_letreiro` | Texto do letreiro | leitura de imagem | texto | ● |  |
| `uso_aparente` | Uso aparente na imagem | leitura de imagem | texto | ● |  |
| `pavimentos_visiveis` | Pavimentos visíveis | leitura de imagem | int | ● |  |
| `unidades_visiveis` | Unidades visíveis | leitura de imagem | int | ● | interfone · caixas de correio · medidores |
| `medidor_visivel` | Medidor visível | leitura de imagem | bool |  |  |

## Aba Receita Federal

*CNPJ com endereço geocodificado e classe física*  
Endereço: sim · Imagem: sim · 34 campos catalogados.

Regra herdada do `tratamento-cnpj`: **situação cadastral não rebaixa evidência física**, e `XFERA_INDICE_EVIDENCIA_OBSERVADA` é tally ordinal — **proibido usar como filtro**.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `cnpj` | CNPJ | identificação | texto | ● |  |
| `razao_social` | Razão social | identificação | texto | ● |  |
| `nome_fantasia` | Nome fantasia | identificação | texto | ● |  |
| `matriz_filial` | Matriz/filial | identificação | texto |  |  |
| `situacao_cadastral` | Situação cadastral | situação | texto | ● |  |
| `data_situacao` | Data da situação | situação | data |  |  |
| `data_abertura` | Data de abertura | situação | data |  |  |
| `porte` | Porte | situação | texto |  |  |
| `natureza_juridica` | Natureza jurídica | situação | texto |  |  |
| `cnae_principal` | CNAE principal | atividade | texto | ● |  |
| `cnae_secundarios` | CNAEs secundários | atividade | lista |  |  |
| `logradouro` | Logradouro | endereço | texto | ● |  |
| `numero` | Número | endereço | texto | ● |  |
| `complemento` | Complemento | endereço | texto | ● |  |
| `bairro` | Bairro | endereço | texto | ● |  |
| `cep` | CEP | endereço | texto | ● |  |
| `lat` | Latitude (via CNEFE) | geo | decimal | ● |  |
| `lon` | Longitude (via CNEFE) | geo | decimal | ● |  |
| `nv_geo_coord` | Nível da coordenada CNEFE | geo | texto |  |  |
| `match_pass` | Passe do casamento | geo | texto |  | P1_EXATO … P4_FUZZY |
| `dist_ancora_m` | Distância à âncora (m) | geo | decimal | ● |  |
| `xfera_classe_fisica` | Classe física | classificação | texto | ● | F1 a F12 |
| `xfera_nivel_evidencia_fisica` | Nível de evidência física | classificação | texto | ● |  |
| `xfera_tipo_presenca_fisica` | Tipo de presença física | classificação | texto | ● |  |
| `xfera_indice_evidencia_observada` | Índice de evidência observada | classificação | int |  | tally ordinal 0-100; proibido usar como filtro |
| `xfera_compatibilidade_atividade` | Compatibilidade da atividade | classificação | texto |  |  |
| `xfera_regra_classificacao` | Regra que decidiu | classificação | texto |  |  |
| `xfera_explicacao_classificacao` | Explicação | classificação | texto |  |  |
| `xfera_contradicoes` | Contradições | classificação | lista |  |  |
| `xfera_observacoes` | Observações | classificação | lista |  |  |
| `xfera_temporalidade_evidencia` | Temporalidade da evidência | classificação | texto |  |  |
| `qtd_familias_confirmadoras` | Famílias confirmadoras | classificação | int |  |  |
| `xfera_rota_tratamento` | Rota de tratamento | classificação | texto |  | RECLASSIFICACAO_1_1 · INDIVIDUALIZACAO_MULTI · VERIFICAR_CAMPO |
| `url_foto` | Imagem do ponto | imagem | imagem |  |  |

## Aba Delivery

*Loja em plataforma de entrega operando no endereço*  
Endereço: sim · Imagem: sim · 29 campos catalogados.

**Trava dura desta fonte:** plataformas de entrega quase sempre publicam o endereço sem número. Enquanto `endereco_precisao` não for `EXATO`, o tier não sobe de `MODERADO` — salvo quando um campo próprio da loja fizer o vínculo (CNPJ na nota, retirada no local). Coleta em plataforma tem termo de uso próprio: fonte contratada ou pública, nunca raspagem silenciosa.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `plataforma` | Plataforma | identificação | texto |  | iFood · Rappi · 99Food · Uber Eats · Aiqfome |
| `id_loja` | ID da loja | identificação | texto |  |  |
| `nome_loja` | Nome da loja | identificação | texto | ● |  |
| `categoria` | Categoria/cozinha | identificação | texto | ● |  |
| `url_loja` | URL da loja | identificação | texto |  |  |
| `endereco_exibido` | Endereço exibido | endereço | texto | ● |  |
| `endereco_precisao` | Precisão do endereço | endereço | texto | ● | EXATO · SEM_NUMERO · SO_BAIRRO · SO_MUNICIPIO — trava o tier |
| `bairro` | Bairro | endereço | texto | ● |  |
| `municipio` | Município | endereço | texto | ● |  |
| `cep` | CEP | endereço | texto | ● |  |
| `lat` | Latitude | geo | decimal | ● |  |
| `lon` | Longitude | geo | decimal | ● |  |
| `dist_ancora_m` | Distância à âncora (m) | geo | decimal | ● |  |
| `status_loja` | Status da loja | operação | texto | ● | ABERTA · FECHADA · PAUSADA · REMOVIDA |
| `horario_semana` | Horário de funcionamento | operação | json |  |  |
| `tempo_entrega_min` | Tempo de entrega (min) | operação | int |  |  |
| `raio_entrega_km` | Raio de entrega (km) | operação | decimal |  |  |
| `aceita_retirada` | Aceita retirada no local | operação | bool | ● | retirada no local = ponto físico atendendo público |
| `pedido_minimo` | Pedido mínimo | operação | decimal |  |  |
| `nota_media` | Nota média | vitalidade | decimal |  |  |
| `qtd_avaliacoes` | Qtd. de avaliações | vitalidade | int |  |  |
| `ultima_avaliacao` | Avaliação mais recente | vitalidade | data | ● |  |
| `n_itens_cardapio` | Itens no cardápio | vitalidade | int |  |  |
| `ultima_atualizacao_cardapio` | Cardápio atualizado em | vitalidade | data | ● |  |
| `prova_vida` | Prova de vida | vitalidade | texto | ● |  |
| `cnpj_declarado` | CNPJ na nota/rodapé | fiscal | texto | ● |  |
| `razao_social_declarada` | Razão social declarada | fiscal | texto | ● |  |
| `url_logo` | Logo | imagem | imagem |  |  |
| `url_foto_fachada` | Foto da fachada | imagem | imagem |  |  |

## Aba Energia

*UC de energia no ponto: classe, carga e nº de UCs*  
Endereço: sim · Imagem: sim · 23 campos catalogados.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `uc` | Unidade consumidora | identificação | texto | ● |  |
| `cod_id_bdgd` | COD_ID (BDGD) | identificação | texto |  |  |
| `distribuidora` | Distribuidora | identificação | texto |  |  |
| `classe_aneel` | Classe ANEEL | classificação | texto | ● |  |
| `subclasse_aneel` | Subclasse ANEEL | classificação | texto | ● |  |
| `grupo_tensao` | Grupo (A/B) | classificação | texto | ● |  |
| `modalidade_tarifaria` | Modalidade tarifária | classificação | texto |  |  |
| `tipo_ligacao` | Tipo de ligação | técnico | texto |  | mono · bi · tri |
| `carga_instalada_kw` | Carga instalada (kW) | técnico | decimal | ● |  |
| `demanda_contratada_kw` | Demanda contratada (kW) | técnico | decimal |  |  |
| `situacao` | Situação | técnico | texto | ● |  |
| `data_conexao` | Data da conexão | técnico | data |  |  |
| `consumo_medio_12m_kwh` | Consumo médio 12m (kWh) | consumo | decimal | ● |  |
| `serie_ene_12m` | Série mensal (ENE_01..12) | consumo | json |  |  |
| `degrau_consumo` | Degrau de consumo | consumo | texto | ● |  |
| `fator_carga` | Fator de carga | consumo | decimal |  |  |
| `n_uc_no_ponto` | UCs no mesmo ponto | cruzamento | int | ● |  |
| `alimentador` | Alimentador | cruzamento | texto |  |  |
| `transformador` | Transformador | cruzamento | texto |  |  |
| `lat` | Latitude | geo | decimal | ● |  |
| `lon` | Longitude | geo | decimal | ● |  |
| `dist_ancora_m` | Distância à âncora (m) | geo | decimal | ● |  |
| `url_foto` | Imagem do ponto | imagem | imagem |  |  |

## Aba Outras Fontes

*CNEFE, OSM, IPTU e demais bases declarativas*  
Endereço: sim · Imagem: sim · 15 campos catalogados.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `fonte_rotulo` | Fonte | identificação | texto |  | CNEFE/IBGE · OSM · Overture · IPTU · anúncios |
| `chave_origem` | Chave na origem | identificação | texto |  |  |
| `descricao` | O que a fonte afirma | identificação | texto | ● |  |
| `logradouro` | Logradouro | endereço | texto | ● |  |
| `numero` | Número | endereço | texto | ● |  |
| `complemento` | Complemento | endereço | texto | ● |  |
| `lat` | Latitude | geo | decimal | ● |  |
| `lon` | Longitude | geo | decimal | ● |  |
| `dist_ancora_m` | Distância à âncora (m) | geo | decimal | ● |  |
| `unidades_declaradas` | Unidades declaradas | conteúdo | int | ● |  |
| `unidades_contadas` | Unidades contadas | conteúdo | int | ● |  |
| `especie` | Espécie do endereço | conteúdo | texto | ● |  |
| `indicador_estab` | Indicador de estabelecimento | conteúdo | texto | ● |  |
| `atributos` | Atributos da fonte | conteúdo | json |  |  |
| `url_foto` | Imagem | imagem | imagem |  |  |

## Aba Resumo da IA

| Campo | Tipo | O que carrega |
|---|---|---|
| `veredito` | texto | a leitura em uma linha |
| `recomendacao` | texto | nomeia a CONSEQUÊNCIA cadastral, não “concordar” |
| `confianca` | int 0–100 | figura única da tela |
| `n_fontes_avaliadas / n_fontes_confirmadoras` | int | confirmadora = ligou ESTA entidade a ESTE ponto |
| `familias_independentes` | int | o número que a regra de corroboração usa |
| `placar` | json | favoráveis · neutras · contraditórias |
| `justificativa` | texto | prosa curta com os fatos, sem adjetivo |
| `evidencias[]` | lista | fonte · peso · texto |
| `contradicoes[]` | lista | o que exige outra fonte antes de decidir |
| `modelo / prompt_hash / data_analise` | texto | reprodutibilidade — fora da tela, no HTML |

## Aba IA das Imagens

Grão: **imagem**. Cada imagem é vinculada à aba da fonte que a trouxe (`fonte_id`), de modo que a mesma leitura aparece nos dois lugares — no carrossel da aba e sob o visor da aba da fonte. O Resumo também carrega a conclusão e uma linha por foto.

Estrutura: `ia_imagens.conclusao` (uma por ligação) + `ia_imagens.itens[]` (uma por imagem).

### Conclusão geral

| Campo | Tipo | O que carrega |
|---|---|---|
| `veredito` | texto | a leitura consolidada das imagens, em uma linha |
| `confianca` | int 0–100 | figura única do cabeçalho e marca `Fotos` na linha de probabilidade |
| `n_imagens` | int | quantas imagens existem |
| `n_uteis` | int | quantas entraram no cômputo — foto de catálogo e imagem obstruída ficam de fora |
| `concordancia` | enum | CONVERGENTE · PARCIAL · DIVERGENTE · INSUFICIENTE |
| `sintese` | texto | por que as imagens dizem o que dizem |
| `contradicoes[]` | lista | o que a imagem não resolve sozinha |
| `modelo / data_analise` | texto | reprodutibilidade |

### Cada imagem, individualmente

Regras duras desta esfera:

- `titular_atividade` separa **ALVO · VIZINHO · AMBULANTE · INDETERMINADO**. Comércio na imagem não é comércio do imóvel enquanto isso não estiver resolvido.
- `unidades_visiveis`, `botoes_interfone` e `caixas_correio` contam **unidade física**. Unidade física não é economia faturável — a conclusão nunca converte uma na outra.
- `captura` sem data, ou anterior ao período em análise, **não decide o presente**: entra como evidência histórica e a ressalva é obrigatória.
- Imagem de catálogo de plataforma não é prova de local e sai do `n_uteis`.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `fonte_id` | Aba de origem | identificação | texto | ● | vincula a imagem a' aba da fonte que a trouxe |
| `origem` | Origem da captura | identificação | texto |  | Street View · Campo · Drone · Plataforma · Catálogo |
| `captura` | Data da captura | identificação | data | ● |  |
| `azimute` | Azimute da câmera | identificação | decimal |  |  |
| `enquadramento` | Enquadramento | identificação | texto |  | FACHADA_FRONTAL · OBLIQUO · INTERIOR · DETALHE · INDETERMINADO |
| `qualidade` | Qualidade da imagem | identificação | texto |  | BOA · REGULAR · RUIM |
| `obstrucao` | Obstrução | identificação | texto |  | veículo, muro, vegetação, sombra |
| `e_imovel` | É imóvel | triagem | bool | ● |  |
| `tipo_alvo` | Tipo do alvo | triagem | texto | ● | IMOVEL · TERRENO_VAGO · VIA · OBRA · INDETERMINADO |
| `atividade_economica` | Atividade econômica visível | triagem | texto | ● | SIM · NAO · INDETERMINADO |
| `titular_atividade` | De quem é a atividade | triagem | texto | ● | ALVO · VIZINHO · AMBULANTE · INDETERMINADO — não confundir vizinho com alvo |
| `numero_ocr` | Número lido na fachada | leitura | texto | ● | confronto independente com o número do cadastro |
| `ocr_confianca` | Confiança do OCR | leitura | decimal |  |  |
| `letreiro` | Letreiro detectado | leitura | bool | ● |  |
| `texto_letreiro` | Texto do letreiro | leitura | texto | ● |  |
| `uso_aparente` | Uso aparente | leitura | texto | ● |  |
| `padrao_construtivo` | Padrão construtivo | leitura | texto | ● |  |
| `pavimentos` | Pavimentos visíveis | estrutura | int | ● |  |
| `unidades_visiveis` | Unidades visíveis | estrutura | int | ● | unidade física — NÃO é economia faturável |
| `botoes_interfone` | Botões de interfone | estrutura | int | ● |  |
| `caixas_correio` | Caixas de correio | estrutura | int | ● |  |
| `medidor_visivel` | Medidor visível | estrutura | bool |  |  |
| `medidor_qtd` | Medidores contados | estrutura | int | ● |  |
| `acesso` | Acesso | estrutura | texto |  | PORTA_UNICA · PORTAO_COLETIVO · MULTIPLAS_PORTAS · GUARITA |
| `veredito` | Veredito da imagem | veredito | texto |  |  |
| `confianca` | Confiança da leitura | veredito | int |  |  |
| `sinais` | Sinais ponderados | veredito | lista |  | peso FORTE · MEDIA · NEUTRA · CONTRARIA |
| `ressalvas` | Ressalvas | veredito | lista |  | o que impede a imagem de decidir sozinha |

## Serviço executado no entorno — `servicos[]`

Indicador do cabeçalho (`servicos_proximos_total`) com **raio e janela declarados no próprio número** — sem isso a contagem não significa nada. Entra em atenção quando há duas ou mais ordens no próprio ponto: serviço recorrente no mesmo lugar é histórico operacional que precede qualquer novo despacho de campo. No banco a contagem é derivada por `radar.servicos_no_entorno(tenant, raio_m, meses)` com `ST_DWithin` em SRID métrico, nunca redigitada na ligação.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `os` | Nº da OS | identificação | texto | ● |  |
| `tipo` | Tipo de serviço | identificação | texto | ● |  |
| `subtipo` | Detalhe | identificação | texto |  |  |
| `data` | Data de execução | identificação | data | ● |  |
| `executante` | Executante | identificação | texto |  |  |
| `dist_m` | Distância à ligação (m) | posição | decimal | ● |  |
| `lat` | Latitude | posição | decimal |  |  |
| `lon` | Longitude | posição | decimal |  |  |
| `x_fachada` | Posição X na fachada | posição | decimal |  | 0 a 1 — usada para marcar a OS sobre a foto |
| `y_fachada` | Posição Y na fachada | posição | decimal |  |  |
| `resultado` | Resultado | desfecho | texto | ● |  |
| `observacao` | Observação do executante | desfecho | texto |  |  |

## Aba Faturas emitidas — `faturas[]`

Grão: **ligação × mês de referência**. É a base própria da concessionária, por isso a aba fica em bloco separado entre a síntese e as fontes externas. A tabela mostra as seis colunas pedidas; o restante do catálogo alimenta os KPIs e as travas.

O cabeçalho traz a **adimplência por VALOR** — soma paga ÷ soma emitida na janela, faturas canceladas fora da conta. Por valor e não por contagem: doze faturas pequenas pagas e uma grande em aberto não é 92% de adimplência.

`valor_comercial` é **hipótese sobre o mesmo consumo na tarifa comercial** — dimensiona a decisão, nunca cobra. `diferenca_comercial` é coluna gerada no banco, não digitada.

No banco, tudo isso é derivado por `radar.adimplencia(tenant, meses)`; a ligação não guarda percentual redigitado.

| Campo | Rótulo na tela | Grupo | Tipo | CMP | Nota |
|---|---|---|---|:--:|---|
| `mes_referencia` | Mês de referência | identificação | data | ● |  |
| `classe` | Classe faturada | identificação | texto | ● | a classe do MÊS — muda quando há reclassificação no meio da série |
| `consumo` | Consumo (m³) | medição | decimal | ● |  |
| `leitura_tipo` | Tipo de leitura | medição | texto | ● | REAL · ESTIMADA · NAO_REALIZADA — estimada não sustenta tese de consumo |
| `ocorrencia_leitura` | Ocorrência da leitura | medição | texto |  |  |
| `valor_consumo` | Valor do consumo (R$) | financeiro | decimal | ● |  |
| `situacao_pagamento` | Situação do pagamento | financeiro | texto | ● | PAGO · EM_ABERTO · EM_ATRASO · PARCELADO · CANCELADA |
| `vencimento` | Vencimento | financeiro | data |  |  |
| `data_pagamento` | Data do pagamento | financeiro | data |  |  |
| `dias_atraso` | Dias de atraso | financeiro | int |  |  |
| `valor_comercial` | Valor comercial (R$) | hipótese | decimal | ● | quanto o mesmo consumo custaria na classe comercial — hipótese, não cobrança |
| `diferenca_comercial` | Δ para a classe comercial (R$) | hipótese | decimal |  | valor_comercial menos valor_consumo; some quando a classe já é comercial |

## Fachada anotada — `fachada`

Duas caixas no Resumo, sobre o mesmo quadro de fachada:

1. **Onde a coordenada cai** — cruz no `ponto_coordenada` e círculo de raio `coord_precisao_m`, desenhado **na escala do quadro** (`largura_m` da testada) e com régua métrica visível. O círculo não é enfeite: é a incerteza declarada, e quando ele cobre mais de uma unidade a tela está dizendo que a coordenada não distingue qual delas.
2. **Onde a concessionária já trabalhou** — uma marca numerada por OS, posicionada por `x_fachada`/`y_fachada`, colorida por tipo, com a OS no hover e a contagem por tipo na legenda.

| Campo | Tipo | Para quê |
|---|---|---|
| `ref` | texto | ponteiro da mídia; a imagem real entra pelo modo externo |
| `captura` | data | data do quadro — sem ela a leitura não decide o presente |
| `largura_m` | decimal | testada enquadrada; é o denominador de toda a escala |
| `ponto_coordenada.x` · `.y` | decimal | 0 a 1 dentro do quadro |
| `coord_precisao_m` | decimal | raio da incerteza declarada |
| `coord_origem` | texto | CNEFE nv=1, régua da face, GPS de campo |
| `nota` | texto | o que a amostragem não resolve |

## Decisão — quatro saídas

| Ação | Status | Quando |
|---|---|---|
| Aprovar | `APROVADO_USUARIO` | a evidência sustenta a recomendação |
| Visita de campo | `DIRECIONADO_CAMPO` | só o local resolve — abre a pauta da visita |
| A revisar | `A_REVISAR` | revisão de mesa: falta dado, não falta ida ao local |
| Rejeitar | `REJEITADO` | a evidência não sustenta nada e o caso sai da fila |

**Visita de campo** não é um botão que muda um rótulo: ele abre a *pauta*, e a pauta nasce do caso. Cada item do catálogo só vem marcado se um fato desta ligação o justifica, e o painel imprime o porquê embaixo do item — hidrômetro não localizado no cadastro, unidades contadas acima das economias faturadas, OCR do número com confiança baixa, mais de uma ligação no endereço, coordenada fora do tier T1, imagem anterior ao período. Item sem fato que o sustente fica desmarcado e **sem justificativa inventada**.

O motivo é pré-selecionado pelo item de maior peso e a prioridade sobe para ALTA quando três ou mais itens entram na pauta. `CHECK ck_campo_tem_pauta` no banco recusa direcionamento sem pauta e sem motivo: mandar a campo sem dizer o que verificar é mandar de novo depois. `radar.v_lote_campo` entrega o lote pendente com dias na fila.

Tabela **append-only** (`RULE ... DO INSTEAD NOTHING` em UPDATE e DELETE). O status vigente é derivado pela última linha, nunca sobrescrito.

| Campo | Para quê |
|---|---|
| `status` | um dos seis do vocabulário |
| `decidido_por` | `motor` para APROVADO_IA; login do conferente para o resto |
| `decidido_em` | carimbo |
| `duracao_ms` | tempo do conferente na ligação — alimenta a métrica de produtividade |
| `concordou_ia` | mede acurácia humano × IA por faixa de confiança |
| `motivo` | **obrigatório** quando discorda da IA (CHECK no DDL) |
| `pauta_campo[]` | **obrigatória** em DIRECIONADO_CAMPO — o que verificar no local |
| `prioridade_campo` | ALTA quando três ou mais itens entram na pauta |
| `observacao` | texto livre do conferente |

## O que a tela faz com o modelo

| Elemento da tela | De onde sai |
|---|---|
| Busca por nº da ligação | `radar.ligacao (tenant, num_ligacao)` — casa também por matrícula |
| % por status | `radar.v_status_base`, uma passada com window function |
| Fila das 10 primeiras | `v_status_atual` × `mv_convergencia`, `ORDER BY prioridade, prob_max DESC LIMIT 10` |
| Linha de probabilidade (1ª linha) | `mv_convergencia.regua` + `imagem_conclusao.confianca` |
| Cabeçalho, faixas 1 e 2 | colunas da âncora, sem join |
| Nome do cliente no cabeçalho | `ligacao.nome_cliente` — campo marcado LGPD, mascarado em exportação |
| Caixa Mesmo endereço | `radar.v_endereco_ligacoes` agrupando por `imovel_id` |
| Caixa Serviço no entorno | `radar.servicos_no_entorno()` com raio e janela como parâmetro |
| Adimplência no cabeçalho | `radar.adimplencia(tenant, meses)` — por valor, derivada |
| Aba Faturas emitidas | `radar.fatura` na janela, ordenada por mês de referência |
| Fachada — coordenada | `radar.fachada` |
| Fachada — serviços | `radar.fachada_os` × `radar.ordem_servico` |
| Aba Resumo | 1 linha por fonte + conclusão e linhas das fotos |
| Aba de fonte | `radar.campo` monta os grupos; `observacao.payload` preenche |
| Aba IA das Imagens | `radar.v_imagem_leitura` + `radar.imagem_conclusao` |
| Mapa lateral | `ligacao.geom` + `observacao.geom`, distância pré-calculada em metros |
| Barra de decisão | `INSERT` em `radar.decisao`; nada é atualizado |
| Pauta da visita de campo | `decisao.pauta_campo[]` + `radar.v_lote_campo` |

Campo novo numa skill de tratamento entra em `radar.campo` e aparece na aba sem tocar no HTML. É o ponto de extensão: a tela lê catálogo, não colunas fixas.

## O que fica fora da tela, mas dentro do HTML

Referência interna não é exibida; vive em atributo, para quem inspeciona o arquivo:

| Some da tela | Onde continua |
|---|---|
| nome técnico da coluna sob cada rótulo | `data-col`, `data-tipo`, `data-cmp` na `.linha` |
| endereço da fonte no topo da aba | `data-endereco-fonte` na faixa de veredito |
| ponteiro da mídia (`ref`) | `data-ref` no quadro de imagem |
| modelo e hash do prompt | `data-modelo`, `data-prompt-hash`, `data-analisado-em` |

## Identidade visual

**Marca.** O `Cadastrae 360` abre a barra superior, do master vetorial do `marca-cadastrae-360` — variante `positivo` (o `ae` em azul Aegea, 10,83:1 sobre branco), 186 px de largura contra o mínimo duro de 180, proporção 4,1826:1 sem deformação, ids de gradiente prefixados para não colidirem com outro SVG da página. O appmark de 64 px vira o favicon embutido. A A2L assina no canto direito com o wordmark vetorial do `marca-a2l` em navy, e o filete 22% laranja + 78% azul continua no topo — duas marcas, dois papéis, sem híbrido.

**Ótica.** Camada A do `estilo-apple-a2l`, inteira:

| Regra | Como entrou |
|---|---|
| Claro é a base | chrome claro; escuro só no visor do mapa e nos quadros de fachada, as duas exceções que a doutrina admite |
| Papéis de cor | título navy `#0B2E59` · corpo grafite `#2A2E35` · apoio `#63697A` · linha `#E0E4EB` |
| Preto puro nunca | nem no texto nem em fundo — o gate reprova `#000000` |
| Tracking óptico | fecha conforme o corpo cresce; a 13,5px o valor correto é zero |
| Grade de 8pt | `--u: 8px`; espaçamentos do chrome são múltiplos |
| Ritmo | cabeçalho branco → faixa `#F2F4F7` nas abas e no palco → cartões brancos sobre a faixa |
| Números | `tabular-nums` em toda figura, para a coluna não dançar entre linhas |
| Vidro fosco | `saturate(170%) blur(22px)` **só na barra superior** |
| Vidro nunca informa | a barra de ação carrega dado, então é superfície opaca; o contexto do lote desceu para o rodapé da lateral |
| Nada anima layout | só `transform`, `opacity` e `clip-path`; `prefers-reduced-motion` desliga tudo |

**Camada B deliberadamente fora**: trilho serpentina, cortina por `clip-path` presa ao scroll, costura entre seções, atmosfera e fixar-e-raspar são dispositivos de *documento que rola*. Este painel tem viewport fixa e rolagem interna por coluna — o scroll-scrub brigaria com o trabalho, e a própria doutrina resolve: *efeito entra quando significa alguma coisa e sai quando vira enfeite*. Pelo mesmo motivo GSAP e Lenis (~135 kB) não foram vendorizados.

### Tipografia

O painel não depende de fonte instalada. **Instrument Sans** (texto) e **JetBrains Mono** (dado) viajam embutidas em woff2 base64, subsetadas para latino completo mais os símbolos da tela — 73,6 KB de fonte, 98,8 KB em base64, ambas SIL OFL 1.1 com a licença declarada no CSS. `SF Pro` continua primeiro na pilha: em máquina Apple a doutrina é atendida com a fonte da plataforma; em qualquer outra, o piso é o mesmo em todo lugar.

**Escala única.** Havia dezessete tamanhos diferentes espalhados entre tokens e literais — incluindo `--t5:11.5px` e `--t6:11px`, dois degraus separados por meio pixel, o que não é hierarquia, é ruído. A tela inteira passou a usar oito degraus, todos inteiros, e o gate mede o `fontSize` computado de cada elemento com texto em cinco abas e reprova qualquer valor fora desta lista:

| Token | Tamanho | Papel |
|---|---|---|
| `--fs-display` | 34px | a figura única: confiança da IA |
| `--fs-xl` | 24px | números de KPI e das caixas de alerta |
| `--fs-lg` | 18px | título de bloco e o número da ligação |
| `--fs-md` | 15px | endereço e valores de destaque |
| `--fs-base` | 13px | corpo, célula de tabela, campo de ficha |
| `--fs-sm` | 12px | apoio: nota, legenda, descrição de fonte |
| `--fs-xs` | 11px | olho, chip, mono pequeno |
| `--fs-2xs` | 10px | micro: rótulo do trilho, legenda do mapa |

Os antigos `--t5` e `--t6` colapsaram num degrau só: o que separa uma nota de um rótulo é peso, caixa e cor, não meio pixel. A entrelinha seguiu o mesmo caminho — quatro papéis (`--lh-figura` 1 · `--lh-ui` 1,3 · `--lh-texto` 1,45 · `--lh-prosa` 1,6) no lugar de doze valores soltos.

Três correções que só apareceram com a fonte real no lugar:

1. **Duas pesagens, não quatro.** O arquivo tem 400 e 700. Todo `font-weight:500` virou 400 e todo `600` virou 700 — antes o navegador sintetizava os intermediários, que é o que borra o texto. O gate reprova qualquer peso computado fora de 400/700.
2. **O espaço da Instrument Sans mede 0,200 em** contra os ~0,26 em de uma grotesca comum: sem correção a palavra cola. `word-spacing:.07em` devolve o espaço efetivo a ~0,27 em, anulado onde o texto é mono.
3. **Tracking negativo só no corpo grande.** A tabela da doutrina fecha o tracking conforme o corpo cresce; a 13,5px o correto é zero, e o −0.006em que estava lá fechava o texto pequeno.

Junto vieram `tabular-nums` em toda figura, cabeçalho de tabela deixando a caixa-alta (é nome de coluna, não sobrancelha), rótulo em caixa-alta limitado a sobrancelha curta — a frase que estava no olho virou legenda do cartão — e o empilhamento dos rótulos da linha de probabilidade passando a ser **medido no DOM** em vez de estimado por percentual: nascem na mesma linha, são medidos e só então sobem. O gate mede sobreposição retângulo a retângulo e reprova em qualquer encosto.

## Faturamento — expansão, sem aba

**Não existe aba de Faturas.** A série vive onde o número aparece, e o número abre a série no lugar — sem trocar de aba, sem perder o contexto do cruzamento.

| Onde | Recorte que abre |
|---|---|
| Caixa `Adimplência` no cabeçalho | série completa, com cabeçalho de pago/emitido, em aberto e Δ para comercial |
| `Adimplência` · `Emitido` · `Consumo médio` no Resumo | série completa + gráfico de consumo mês a mês |
| `Em aberto` | só as faturas em aberto ou em atraso |
| `Leitura não real` | só os meses estimados ou não lidos |
| `Δ classe comercial` | cada mês com o valor faturado ao lado do que custaria na tarifa comercial |

Uma figura por vez fica marcada; clicar de novo recolhe. As três renderizações da tabela — popover do cabeçalho, expansão do Resumo e recortes — saem da mesma função `tabelaFaturas()`.


## Popovers do cabeçalho

As três caixas do cabeçalho (mesmo endereço, serviço no entorno e coordenada) abrem menus em `position:fixed`, posicionados pelo retângulo do próprio botão. **Não é preferência de estilo:** as faixas do cabeçalho têm `overflow:hidden` porque o divisor precisa enrolá-las, e qualquer popover posicionado por `absolute` era recortado — a caixa parecia não expandir. O abridor é um só para os três, alinha o menu pela direita do botão, empurra para dentro da janela quando falta espaço e limita a altura com rolagem quando a janela é baixa.


## Assistente de dados

O assistente chama-se **Arthur**, definido em `meta.assistente.nome`. Caixa flutuante de 468x660, minimizável, arrastável pelo cabeçalho e **redimensionável pela pega do canto superior esquerdo** — ela cresce para cima e para a esquerda, porque a caixa mora no canto de baixo à direita; duplo clique devolve o padrão. Atalho `A` abre, `Esc` minimiza. O histórico sobrevive ao minimizar e as sugestões são recalculadas a cada ligação aberta — saem do caso, não de uma lista fixa.

> Defeito que só a execução pegou: a bolha do assistente nascia com `class="assist-msg assist"`, e o modificador `assist` colidia com a classe da **caixa** — cada mensagem herdava `position:fixed` e o tamanho dela, virando um retângulo branco por cima de tudo. Os modificadores passaram a ser `de-assist` e `de-user`, e um gate reprova qualquer mensagem que carregue a classe do contêiner.

**Dois modos, declarados em `meta.assistente`:**

| `endpoint` | Comportamento |
|---|---|
| nulo (padrão) | responde **localmente**, por regra determinística, só com o que está carregado |
| definido | encaminha `{pergunta, num_ligacao, ancora, ia}` ao serviço e mostra a volta |

O modo local **não é modelo de linguagem** e o painel não finge que é: é um respondedor por regra que lê o dossiê da ligação aberta e o lote. Ele cobre treze intenções — ligações no mesmo endereço, hidrômetro e ocorrências, contagem de economias, faturas e adimplência, consumo e leitura estimada, diferença para a tarifa comercial, leitura das imagens, serviços no entorno, coordenada e incerteza, quais fontes confirmam, recomendação da IA, cliente, e situação do lote.

Duas regras duras, cobertas por teste:

- **Toda resposta declara a origem** do número, numa linha ao pé da bolha (*caixa Mesmo endereço · agrupamento por imovel_id*, *série de faturas da janela*, *aba IA das Imagens*).
- **Sem regra que case, ele diz que não sabe** e lista o que sabe responder. Não completa lacuna com texto plausível.

As ressalvas do modelo viajam nas respostas: o Δ comercial sai sempre marcado como hipótese, e a contagem de unidades sai sempre com *unidade física não é economia faturável*.


## Coordenada — abrir no Google

A coordenada do cabeçalho é acionável. O menu oferece quatro saídas, e a primeira é a que importa:

| Opção | O que faz |
|---|---|
| **Tela dividida no Google** | abre duas janelas em metades da tela: Street View à esquerda, no azimute que a leitura de imagem declarou, e satélite à direita, no mesmo ponto |
| Só Street View | uma janela, mesmo azimute |
| Só satélite | uma janela, zoom 19 |
| Copiar coordenada | para colar no que o operador já usa |

As duas janelas usam a **Maps URLs API oficial** (`map_action=pano` e `map_action=map&basemap=satellite`) — sem chave, sem embed e sem URL não documentada. A geometria vem de `screen.availWidth/availHeight`, então as janelas ficam lado a lado sem sobrepor, verificado no gate. Se o navegador bloquear a segunda janela, o painel avisa em vez de abrir só metade e fingir que deu certo.

**Por que não um split embutido no painel:** o Maps Embed API exige chave de API, e o arquivo é offline e autocontido. Embutir via URL não documentada funcionaria hoje e quebraria sem aviso. Duas janelas reais dão o mesmo resultado com contrato estável.


## Escala da linha de probabilidade

A escala **não é linear**. Numa régua linear a metade esquerda fica vazia — as fontes se aglomeram acima de 70 e os rótulos empilham em cinco linhas. A posição é `x = (p/100)³`, com um parâmetro só (`EXPO`), monotônica, `0→0` e `100→100`:

| Probabilidade | Posição na régua |
|---|---|
| 50 | 12,5% |
| 75 | 42% |
| 90 | 73% |
| 100 | 100% |

As marcas do eixo mudaram de `0·25·50·75·100` para **`0·50·75·90·100`**: com passo desigual elas mostram a compressão em vez de escondê-la, e o `title` do rótulo declara a escala. Medido no lote: o empilhamento dos rótulos caiu de 5 linhas para 3, e a faixa de sinais ficou nos 110px sem precisar apagar nenhum rótulo.

**Ressalva:** distância na régua não é diferença de probabilidade. A escala serve para separar o que se aglomera no topo; a leitura quantitativa é o número ao lado de cada fonte, no Resumo.


## Faixa de sinais

A linha de probabilidade e as três caixas de alerta dividem **uma única faixa**, não duas. A régua ocupa o espaço que sobra (`flex:1 1 340px`, mínimo 280px) e as caixas são uma grade de três colunas de 206px — mesma largura, mesma altura, rótulos no mesmo topo. Testado em 1780, 1440 e 1280px: sempre uma linha só, 110px de altura contra os ~204px que as duas faixas empilhadas custavam.

Dois detalhes que a execução impôs:

- O rótulo em caixa-alta estava com `flex:1` herdado e **crescia junto com a caixa**, roubando a altura dela — era por isso que a primeira caixa media 54px e as outras 60px. Fixado em `flex:0 0 auto`; as três passaram a medir 80px.
- Com a régua mais estreita, os rótulos das fontes empilham em mais linhas. O empilhamento por medida ganhou teto de 5 linhas: além dele o rótulo se apaga e sobra a marca com `title`, para a faixa não crescer sem controle.

Os textos das caixas foram encurtados para caberem em uma linha, já que o rótulo acima diz o assunto: *ligações no imóvel* · *em 100 m · 36 meses* · *do valor emitido*.


## Divisores da tela

Três regiões redimensionáveis, todas com arraste, duplo clique para o padrão e setas pelo teclado — o conferente ajusta a tela ao que está fazendo em vez de rolar:

| Divisor | Faixa | O que cede |
|---|---|---|
| Lateral × análise | 208–460 px | a fila ganha largura para o nome do cliente; a análise cede |
| Análise × coluna direita | 300–820 px | mapa e fachada crescem; a tabela cede |
| Cabeçalho × análise | 3 degraus | veja abaixo |

O divisor do cabeçalho **não é altura livre — é degrau**, porque meia linha cortada não informa nada:

| Degrau | O que fica | Altura do cabeçalho |
|---|---|---|
| 0 | sinais + identidade + atributos | ~300 px |
| 1 | identidade + atributos | ~180 px |
| 2 | só identidade | ~119 px |

A identidade e as abas nunca somem, em degrau nenhum. No degrau 2 a área de análise vai a 813 px numa tela de 1010 — o dobro do que sobrava antes. Cada mudança redesenha o mapa e reempilha os rótulos da linha de probabilidade, que dependem de largura medida.


## Revisão externa — o que entrou e o que não entrou

| Sugestão | Decisão | Por quê |
|---|---|---|
| Busca por nome e documento | **entrou** | `acha()` casa número, matrícula, CPF/CNPJ, nome do cliente e logradouro |
| Contradições antes da justificativa | **entrou** | estavam por último; agora abrem o cartão em faixa própria |
| Coluna direita redimensionável | **entrou** | puxador com arraste, duplo clique para o padrão e setas pelo teclado |
| Payload duplicado | **entrou, por referência** | as 37 cópias apontam `dossie_ref` em vez de carregar o dossiê: payload de 766 KB para 160 KB |
| Travessão chumbado no HTML | **entrou** | os campos nascem vazios; a ausência vira `<em class="sr">sem dado</em>` com o travessão em `aria-hidden` |
| Realce do OCR na imagem | **parcial** | o campo lido salta para a imagem; o realce da área exige `bbox` que a leitura ainda não entrega |
| Reordenar abas por tier | **recusado** | quebra memória posicional: a aba muda de lugar a cada ligação. No lugar, o badge da aba ganhou a cor do tier |
| Acordeão na faixa de atributos | **recusado** | classe, situação, economias, hidrômetro e coordenadas se olha em toda ligação; esconder custa um clique por caso |
| Inverter identidade e métricas no topo | **em aberto** | contraria pedido explícito anterior (linha de probabilidade como primeira linha); decisão do usuário |
| Skeleton loaders | **recusado** | o payload vem embutido e renderiza síncrono; não há espera para preencher |

## Pendências declaradas

1. Conciliar Delivery e Redes Sociais contra a fonte original assim que ela estiver acessível.
2. `prob_base` está `DECLARADA` em 100% do lote — calibrar exige amostra de campo rotulada.
3. Mídia: o painel guarda a referência da imagem, a data e o azimute; a mídia real entra pelo modo externo, não embutida. Os quadros de fachada desenham a anotação sobre um gabarito até que a mídia real esteja plugada.
4. LGPD: `radar.campo.lgpd` já marca titular e telefone; falta a política de mascaramento no read model antes de qualquer exportação.
